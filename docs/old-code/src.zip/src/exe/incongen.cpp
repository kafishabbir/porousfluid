#include "incongen/manager.h"


int main()
{
	incongen::Manager::run();
	return 0;
}
