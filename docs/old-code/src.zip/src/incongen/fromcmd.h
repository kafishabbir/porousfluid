#ifndef INCONGEN_FROMCMD_H
#define INCONGEN_FROMCMD_H

namespace incongen
{
	class FromCmd
	{

	public:
		static bool generate();

	};




}

#endif
