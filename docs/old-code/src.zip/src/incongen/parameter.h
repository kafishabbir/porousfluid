#ifndef INCONGEN_PARAMETER_H
#define INCONGEN_PARAMETER_H

namespace incongen
{

	class Parameter
	{

	public:
	};


}




#endif
