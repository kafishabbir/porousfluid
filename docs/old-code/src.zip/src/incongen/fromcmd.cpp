#include "incongen/fromcmd.h"



bool incongen::FromCmd::generate()
{
	std::cout << "Generating from command line inter face, does not work at the moment" << std::endl;


	return true;
}
