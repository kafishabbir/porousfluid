#ifndef INCONGEN_T_MNS_H
#define INCONGEN_T_MNS_H

namespace incongen
{

	class TMns
	{

	public:

	};


}




#endif
