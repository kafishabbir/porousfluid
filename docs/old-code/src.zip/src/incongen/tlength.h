#ifndef INCONGEN_T_LENGTH_H
#define INCONGEN_T_LENGTH_H

namespace incongen
{
	class TLength
	{

	public:

	};



}




#endif
