#ifndef INCONGEN_T_RADIUS_H
#define INCONGEN_T_RADIUS_H

namespace incongen
{
	class TRadius
	{

	public:
		static void write_to_file(const std::pair<std::string, double>& cat_and_val);
	};
}




















































		);
	};

}




#endif
