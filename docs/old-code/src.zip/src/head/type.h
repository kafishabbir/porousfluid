#ifndef HEAD_TYPE_H
#define HEAD_TYPE_H
#include "dst/mns.h"

typedef std::vector<std::vector<double>> tdouble_type;
typedef std::vector<std::vector<dst::Mns>> tmns_type;


#endif
